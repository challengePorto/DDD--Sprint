package org.example.model;

import java.util.Date;

public class Apolice {
    private int numero;
    private String seguradora;
    private double valor;
    private Date dataInicio; // Adicionando campo de data de início
    private Date dataFim; // Adicionando campo de data de fim

    public Apolice(int numero, String seguradora, Date dataInicio, Date dataFim, double valor) {
        this.numero = numero;
        this.seguradora = seguradora;
        this.dataInicio = dataInicio;
        this.dataFim = dataFim;
        this.valor = valor;
    }

    // Métodos getter e setter para os campos de data
    public Date getDataInicio() {
        return dataInicio;
    }

    public void setDataInicio(Date dataInicio) {
        this.dataInicio = dataInicio;
    }

    public Date getDataFim() {
        return dataFim;
    }

    public void setDataFim(Date dataFim) {
        this.dataFim = dataFim;
    }

    // Métodos getter e setter para os outros campos
    public int getNumero() {
        return numero;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }

    public String getSeguradora() {
        return seguradora;
    }

    public void setSeguradora(String seguradora) {
        this.seguradora = seguradora;
    }

    public double getValor() {
        return valor;
    }

    public void setValor(double valor) {
        this.valor = valor;
    }

    @Override
    public String toString() {
        return "Apolice [Número=" + numero + ", Seguradora=" + seguradora + ", Data de Início=" + dataInicio
                + ", Data de Fim=" + dataFim + ", Valor=" + valor + "]";
    }
}
