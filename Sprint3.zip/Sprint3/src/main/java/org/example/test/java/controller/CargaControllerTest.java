package org.example.test.java.controller;

import org.example.controller.CargaController;
import org.example.model.Carga;
import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

public class CargaControllerTest {
    private CargaController cargaController;
    private List<Carga> listaDeCargas;

    @Before
    public void setUp() {
        listaDeCargas = new ArrayList<>();
        cargaController = new CargaController(listaDeCargas, null); // O segundo parâmetro pode ser um scanner simulado
    }

    @Test
    public void testCriarCarga() {
        Carga novaCarga = new Carga(1, "Carga de Teste", 1000.0);
        cargaController.criar(novaCarga);

        assertEquals(1, listaDeCargas.size());
        Carga cargaCriada = listaDeCargas.get(0);
        assertEquals(novaCarga, cargaCriada);
    }

    @Test
    public void testLerCargaExistente() {
        Carga cargaExistente = new Carga(1, "Carga de Teste", 1000.0);
        listaDeCargas.add(cargaExistente);

        Carga cargaLida = cargaController.ler(1);

        assertNotNull(cargaLida);
        assertEquals(cargaExistente, cargaLida);
    }

    @Test
    public void testLerCargaInexistente() {
        Carga cargaLida = cargaController.ler(1);

        assertNull(cargaLida);
    }

    @Test
    public void testAtualizarCargaExistente() {
        Carga cargaExistente = new Carga(1, "Carga Antiga", 500.0);
        listaDeCargas.add(cargaExistente);

        Carga cargaAtualizada = new Carga(1, "Carga Atualizada", 750.0);
        cargaController.atualizar(cargaAtualizada);

        assertEquals(1, listaDeCargas.size());
        Carga cargaModificada = listaDeCargas.get(0);
        assertEquals(cargaAtualizada, cargaModificada);
    }

    @Test
    public void testAtualizarCargaInexistente() {
        Carga cargaAtualizada = new Carga(1, "Carga Atualizada", 750.0);
        cargaController.atualizar(cargaAtualizada);

        assertEquals(0, listaDeCargas.size());
    }

    @Test
    public void testDeletarCargaExistente() {
        Carga cargaExistente = new Carga(1, "Carga de Teste", 1000.0);
        listaDeCargas.add(cargaExistente);

        cargaController.deletar(1);

        assertEquals(0, listaDeCargas.size());
    }

    @Test
    public void testDeletarCargaInexistente() {
        cargaController.deletar(1);

        assertEquals(0, listaDeCargas.size());
    }
}
