package org.example.test.java.controller;

import org.example.controller.ApoliceController;
import org.example.model.Apolice;
import org.junit.Before;
import org.junit.Test;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.lang.reflect.Field;
import java.util.Scanner;
import java.util.ArrayList;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

public class ApoliceControllerTest {
    private ApoliceController apoliceController;

    @Before
    public void setUp() {
        List<Apolice> listaDeApolices = new ArrayList<>(); // Crie a lista de apólices
        Scanner scanner = new Scanner(System.in); // Crie um scanner (pode ser falso para testes)
        apoliceController = new ApoliceController(listaDeApolices, scanner);
    }

    @Test
    public void testCadastrarApolice() throws ParseException, NoSuchFieldException, IllegalAccessException {
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        Date dataInicio = dateFormat.parse("2023-09-01");
        Date dataFim = dateFormat.parse("2023-12-31");
        Apolice novaApolice = new Apolice(1, "Seguradora Teste", dataInicio, dataFim, 1000.0);

        apoliceController.criar(novaApolice);

        // Usando reflexão para acessar a listaDeApolices privada
        Field field = ApoliceController.class.getDeclaredField("listaDeApolices");
        field.setAccessible(true);
        List<Apolice> apolices = (List<Apolice>) field.get(apoliceController);

        boolean encontrada = false;
        for (Apolice apolice : apolices) {
            if (apolice.getNumero() == novaApolice.getNumero()) {
                encontrada = true;
                assertEquals("Seguradora Teste", apolice.getSeguradora());
                assertEquals(dataInicio, apolice.getDataInicio());
                assertEquals(dataFim, apolice.getDataFim());
                assertEquals(1000.0, apolice.getValor(), 0.001); // Comparação de valores de ponto flutuante
                break;
            }
        }

        assertEquals(true, encontrada);
    }
    @Test
    public void testLerApolice() throws ParseException {
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        Date dataInicio = dateFormat.parse("2023-09-01");
        Date dataFim = dateFormat.parse("2023-12-31");
        Apolice novaApolice = new Apolice(1, "Seguradora Teste", dataInicio, dataFim, 1000.0);

        apoliceController.criar(novaApolice);

        Apolice apoliceLida = apoliceController.ler(1);

        assertNotNull(apoliceLida);
        assertEquals("Seguradora Teste", apoliceLida.getSeguradora());
        assertEquals(dataInicio, apoliceLida.getDataInicio());
        assertEquals(dataFim, apoliceLida.getDataFim());
        assertEquals(1000.0, apoliceLida.getValor(), 0.001);
    }

    @Test
    public void testAtualizarApolice() throws ParseException {
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        Date dataInicio = dateFormat.parse("2023-09-01");
        Date dataFim = dateFormat.parse("2023-12-31");
        Apolice novaApolice = new Apolice(1, "Seguradora Teste", dataInicio, dataFim, 1000.0);

        apoliceController.criar(novaApolice);

        Apolice apoliceAtualizada = new Apolice(1, "Nova Seguradora", dataInicio, dataFim, 1500.0);

        apoliceController.atualizar(apoliceAtualizada);

        Apolice apoliceLida = apoliceController.ler(1);

        assertNotNull(apoliceLida);
        assertEquals("Nova Seguradora", apoliceLida.getSeguradora());
        assertEquals(1500.0, apoliceLida.getValor(), 0.001);
    }

    @Test
    public void testDeletarApolice() throws ParseException {
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        Date dataInicio = dateFormat.parse("2023-09-01");
        Date dataFim = dateFormat.parse("2023-12-31");
        Apolice novaApolice = new Apolice(1, "Seguradora Teste", dataInicio, dataFim, 1000.0);

        apoliceController.criar(novaApolice);

        apoliceController.deletar(1);

        Apolice apoliceLida = apoliceController.ler(1);

        assertNull(apoliceLida);
    }
}
