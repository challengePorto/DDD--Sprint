package org.example.test.java.controller;

import org.example.controller.ApoliceController;
import org.example.controller.CargaController;
import org.example.controller.MenuController;
import org.example.controller.VeiculoController;
import org.example.view.MenuView;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.util.Scanner;

import static org.mockito.Mockito.*;

public class MenuControllerTest {
    private MenuController menuController;
    private ApoliceController apoliceController;
    private CargaController cargaController;
    private VeiculoController veiculoController;
    private MenuView menuView;

    @Before
    public void setUp() {
        // Configurar os controladores e a visão do menu como simulados (mocks)
        apoliceController = mock(ApoliceController.class);
        cargaController = mock(CargaController.class);
        veiculoController = mock(VeiculoController.class);
        menuView = mock(MenuView.class);

        // Configurar a entrada de teste para simular a escolha do usuário
        String input = "2\n4\n"; // Primeiro, escolher opção 2 (gerenciar cargas), depois opção 4 (sair)
        InputStream inputStream = new ByteArrayInputStream(input.getBytes());
        Scanner scanner = new Scanner(inputStream);

        // Criar o MenuController com os controladores simulados e a entrada de teste
        menuController = new MenuController(scanner, menuView, apoliceController, cargaController, veiculoController);
    }

    @Test
    public void testExibirMenuPrincipal() {
        // Configurar o comportamento esperado ao chamar os métodos dos controladores
        doNothing().when(apoliceController).gerenciarApolices();
        doNothing().when(cargaController).gerenciarCargas();
        doNothing().when(veiculoController).gerenciarVeiculos();

        // Executar o método de teste
        menuController.exibirMenuPrincipal();

        // Verificar se os métodos dos controladores foram chamados corretamente
        verifyZeroInteractions(apoliceController);
        verify(cargaController).gerenciarCargas();
        verifyZeroInteractions(veiculoController);
    }
}
